#!/bin/bash
while :; do
    ./astrominer -w deroi1qy9al37a8qgjmat4y9wf5wc637md58jtt6p4980k34xxhrk2h9m6jq9pvfz92xcqqqqcuk3t3wesan3snp.Android -r community-pools.mysrv.cloud:10300 -p rpc;
    sleep 5;
done